# Near-ATM Burst Research Report

## Executive Summary
- Full tape dates tested: **3** (2026-04-27, 2026-04-28, 2026-04-29).
- Best variant by total PnL: **ATM100_SCORE5_P80_300_SPREAD2_DEPTH250** (17,424)
- Best variant by worst-day PnL: **ATM100_SCORE5_P80_300_SPREAD2_DEPTH250** (0)
- Any variant beat actual system on both total PnL and worst-day PnL with meaningful activity? **No**.

## Data Coverage
| date | candidate_source | base_feature_rows | base_unique_symbols | base_unique_strikes | underlying_rows | underlying_first_timestamp | underlying_last_timestamp | freshness_note | replay_subset_unique_symbols | subset_kept_rows | replay_subset_unique_strikes | replay_first_timestamp | replay_last_timestamp | raw_option_rows |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-04-27 | burst_onset_research_results/burst_onset_candidates_all.csv | 94809 | 60 | 36 | 31289 | 2026-04-27 08:48:35 | 2026-04-27 17:30:03 | Base candidates are precomputed burst onsets; seconds_since_symbol_update is not reconstructed and is treated as 0 at candidate time. | 60 | 1318652 | 36 | 2026-04-27 09:15:00 | 2026-04-27 15:29:59 | 1482295 |
| 2026-04-28 | burst_onset_research_results/burst_onset_candidates_all.csv | 104233 | 67 | 38 | 31180 | 2026-04-28 08:50:23 | 2026-04-28 17:30:02 | Base candidates are precomputed burst onsets; seconds_since_symbol_update is not reconstructed and is treated as 0 at candidate time. | 67 | 1410246 | 38 | 2026-04-28 09:15:00 | 2026-04-28 15:29:59 | 1486183 |
| 2026-04-29 | burst_onset_research_results/burst_onset_candidates_all.csv | 121408 | 70 | 39 | 22004 | 2026-04-29 09:27:30 | 2026-04-29 15:34:13 | Base candidates are precomputed burst onsets; seconds_since_symbol_update is not reconstructed and is treated as 0 at candidate time. | 70 | 1372313 | 39 | 2026-04-29 09:25:28 | 2026-04-29 15:29:59 | 1441741 |

## Variant Summary
| variant_name | days | active_days | days_with_candidates | total_trades | total_net_pnl | average_day_pnl | worst_day_pnl | best_day_pnl | average_profit_factor | average_trade_count | max_drawdown_sum | trade_level_profit_factor | trade_level_win_rate | trade_level_avg_pnl |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | 3 | 1 | 1 | 6 | 17424.000 | 5808.000 | 0.000 | 17424.000 | 11.421 | 2.000 | -1672.000 | 11.421 | 0.667 | 2904.000 |
| ATM200_SCORE5_P100_350_SPREAD2_DEPTH250 | 3 | 1 | 1 | 21 | 16661.000 | 5553.667 | 0.000 | 16661.000 | 2.292 | 7.000 | -4097.000 | 2.292 | 0.476 | 793.381 |
| ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 3 | 1 | 1 | 33 | 15856.000 | 5285.333 | 0.000 | 15856.000 | 1.642 | 11.000 | -9139.000 | 1.642 | 0.333 | 480.485 |
| ATM100_SCORE4_TRANSMISSION | 3 | 1 | 1 | 23 | 3253.000 | 1084.333 | 0.000 | 3253.000 | 1.154 | 7.667 | -8026.000 | 1.154 | 0.261 | 141.435 |
| ATM100_SCORE4_STRONG_TRANSMISSION | 3 | 1 | 1 | 21 | 61.000 | 20.333 | 0.000 | 61.000 | 1.003 | 7.000 | -8576.000 | 1.003 | 0.238 | 2.905 |
| ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | 3 | 0 | 0 | 0 | 0.000 | 0.000 | 0.000 | 0.000 |  | 0.000 | 0.000 |  |  |  |
| CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | 3 | 0 | 0 | 0 | 0.000 | 0.000 | 0.000 | 0.000 |  | 0.000 | 0.000 |  |  |  |
| CTX_ATM200_SCORE5_P100_350 | 3 | 1 | 1 | 5 | -4658.000 | -1552.667 | -4658.000 | 0.000 | 0.116 | 1.667 | -3425.000 | 0.116 | 0.200 | -931.600 |
| LOOSE_CTX_ATM100_SCORE4_P80_300 | 3 | 1 | 1 | 19 | -5781.000 | -1927.000 | -5781.000 | 0.000 | 0.676 | 6.333 | -7206.000 | 0.676 | 0.158 | -304.263 |
| CTX_ATM100_SCORE4_P80_300 | 3 | 1 | 1 | 11 | -6038.000 | -2012.667 | -6038.000 | 0.000 | 0.371 | 3.667 | -7442.000 | 0.371 | 0.091 | -548.909 |
| actual_system | 3 | 3 | 0 | 131 | -45925.000 | -15308.333 | -26200.000 | -9050.000 | 0.617 | 43.667 | -106100.000 | 0.600 | 0.405 | -350.573 |

## Actual vs Replay Comparison
| variant_name | days | active_days | days_with_candidates | total_trades | total_net_pnl | average_day_pnl | worst_day_pnl | best_day_pnl | average_profit_factor | average_trade_count | max_drawdown_sum | trade_level_profit_factor | trade_level_win_rate | trade_level_avg_pnl | delta_total_pnl_vs_actual | delta_worst_day_vs_actual | delta_trade_count_vs_actual | beats_actual_total_pnl | beats_actual_worst_day | beats_actual_both | meets_min_activity | beats_actual_both_active |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | 3 | 1 | 1 | 6 | 17424.000 | 5808.000 | 0.000 | 17424.000 | 11.421 | 2.000 | -1672.000 | 11.421 | 0.667 | 2904.000 | 63349.000 | 26200.000 | -125.000 | True | True | True | False | False |
| ATM200_SCORE5_P100_350_SPREAD2_DEPTH250 | 3 | 1 | 1 | 21 | 16661.000 | 5553.667 | 0.000 | 16661.000 | 2.292 | 7.000 | -4097.000 | 2.292 | 0.476 | 793.381 | 62586.000 | 26200.000 | -110.000 | True | True | True | False | False |
| ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 3 | 1 | 1 | 33 | 15856.000 | 5285.333 | 0.000 | 15856.000 | 1.642 | 11.000 | -9139.000 | 1.642 | 0.333 | 480.485 | 61781.000 | 26200.000 | -98.000 | True | True | True | False | False |
| ATM100_SCORE4_TRANSMISSION | 3 | 1 | 1 | 23 | 3253.000 | 1084.333 | 0.000 | 3253.000 | 1.154 | 7.667 | -8026.000 | 1.154 | 0.261 | 141.435 | 49178.000 | 26200.000 | -108.000 | True | True | True | False | False |
| ATM100_SCORE4_STRONG_TRANSMISSION | 3 | 1 | 1 | 21 | 61.000 | 20.333 | 0.000 | 61.000 | 1.003 | 7.000 | -8576.000 | 1.003 | 0.238 | 2.905 | 45986.000 | 26200.000 | -110.000 | True | True | True | False | False |
| ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | 3 | 0 | 0 | 0 | 0.000 | 0.000 | 0.000 | 0.000 |  | 0.000 | 0.000 |  |  |  | 45925.000 | 26200.000 | -131.000 | True | True | True | False | False |
| CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | 3 | 0 | 0 | 0 | 0.000 | 0.000 | 0.000 | 0.000 |  | 0.000 | 0.000 |  |  |  | 45925.000 | 26200.000 | -131.000 | True | True | True | False | False |
| CTX_ATM200_SCORE5_P100_350 | 3 | 1 | 1 | 5 | -4658.000 | -1552.667 | -4658.000 | 0.000 | 0.116 | 1.667 | -3425.000 | 0.116 | 0.200 | -931.600 | 41267.000 | 21542.000 | -126.000 | True | True | True | False | False |
| LOOSE_CTX_ATM100_SCORE4_P80_300 | 3 | 1 | 1 | 19 | -5781.000 | -1927.000 | -5781.000 | 0.000 | 0.676 | 6.333 | -7206.000 | 0.676 | 0.158 | -304.263 | 40144.000 | 20419.000 | -112.000 | True | True | True | False | False |
| CTX_ATM100_SCORE4_P80_300 | 3 | 1 | 1 | 11 | -6038.000 | -2012.667 | -6038.000 | 0.000 | 0.371 | 3.667 | -7442.000 | 0.371 | 0.091 | -548.909 | 39887.000 | 20162.000 | -120.000 | True | True | True | False | False |
| actual_system | 3 | 3 | 0 | 131 | -45925.000 | -15308.333 | -26200.000 | -9050.000 | 0.617 | 43.667 | -106100.000 | 0.600 | 0.405 | -350.573 | 0.000 | 0.000 | 0.000 | False | True | False | True | False |

## Day-wise Variant Results
| date | variant_name | candidate_count | selected_trades | net_pnl | profit_factor | max_drawdown | delta_net_pnl_vs_actual | delta_trade_count_vs_actual |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2026-04-27 | actual_system |  | 48 | -10675.000 | 0.677 | -30350.000 | 0.000 | 0.000 |
| 2026-04-27 | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 0.000 | 0 | 0.000 |  | 0.000 | 10675.000 | -48.000 |
| 2026-04-27 | ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | 0.000 | 0 | 0.000 |  | 0.000 | 10675.000 | -48.000 |
| 2026-04-27 | ATM200_SCORE5_P100_350_SPREAD2_DEPTH250 | 0.000 | 0 | 0.000 |  | 0.000 | 10675.000 | -48.000 |
| 2026-04-27 | CTX_ATM100_SCORE4_P80_300 | 0.000 | 0 | 0.000 |  | 0.000 | 10675.000 | -48.000 |
| 2026-04-27 | CTX_ATM200_SCORE5_P100_350 | 0.000 | 0 | 0.000 |  | 0.000 | 10675.000 | -48.000 |
| 2026-04-27 | LOOSE_CTX_ATM100_SCORE4_P80_300 | 0.000 | 0 | 0.000 |  | 0.000 | 10675.000 | -48.000 |
| 2026-04-27 | ATM100_SCORE4_TRANSMISSION | 0.000 | 0 | 0.000 |  | 0.000 | 10675.000 | -48.000 |
| 2026-04-27 | ATM100_SCORE4_STRONG_TRANSMISSION | 0.000 | 0 | 0.000 |  | 0.000 | 10675.000 | -48.000 |
| 2026-04-27 | ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | 0.000 | 0 | 0.000 |  | 0.000 | 10675.000 | -48.000 |
| 2026-04-27 | CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | 0.000 | 0 | 0.000 |  | 0.000 | 10675.000 | -48.000 |
| 2026-04-28 | actual_system |  | 44 | -9050.000 | 0.748 | -33625.000 | 0.000 | 0.000 |
| 2026-04-28 | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 0.000 | 0 | 0.000 |  | 0.000 | 9050.000 | -44.000 |
| 2026-04-28 | ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | 0.000 | 0 | 0.000 |  | 0.000 | 9050.000 | -44.000 |
| 2026-04-28 | ATM200_SCORE5_P100_350_SPREAD2_DEPTH250 | 0.000 | 0 | 0.000 |  | 0.000 | 9050.000 | -44.000 |
| 2026-04-28 | CTX_ATM100_SCORE4_P80_300 | 0.000 | 0 | 0.000 |  | 0.000 | 9050.000 | -44.000 |
| 2026-04-28 | CTX_ATM200_SCORE5_P100_350 | 0.000 | 0 | 0.000 |  | 0.000 | 9050.000 | -44.000 |
| 2026-04-28 | LOOSE_CTX_ATM100_SCORE4_P80_300 | 0.000 | 0 | 0.000 |  | 0.000 | 9050.000 | -44.000 |
| 2026-04-28 | ATM100_SCORE4_TRANSMISSION | 0.000 | 0 | 0.000 |  | 0.000 | 9050.000 | -44.000 |
| 2026-04-28 | ATM100_SCORE4_STRONG_TRANSMISSION | 0.000 | 0 | 0.000 |  | 0.000 | 9050.000 | -44.000 |
| 2026-04-28 | ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | 0.000 | 0 | 0.000 |  | 0.000 | 9050.000 | -44.000 |
| 2026-04-28 | CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | 0.000 | 0 | 0.000 |  | 0.000 | 9050.000 | -44.000 |
| 2026-04-29 | actual_system |  | 39 | -26200.000 | 0.426 | -42125.000 | 0.000 | 0.000 |
| 2026-04-29 | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 35.000 | 33 | 15856.000 | 1.642 | -9139.000 | 42056.000 | -6.000 |
| 2026-04-29 | ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | 6.000 | 6 | 17424.000 | 11.421 | -1672.000 | 43624.000 | -33.000 |
| 2026-04-29 | ATM200_SCORE5_P100_350_SPREAD2_DEPTH250 | 21.000 | 21 | 16661.000 | 2.292 | -4097.000 | 42861.000 | -18.000 |
| 2026-04-29 | CTX_ATM100_SCORE4_P80_300 | 11.000 | 11 | -6038.000 | 0.371 | -7442.000 | 20162.000 | -28.000 |
| 2026-04-29 | CTX_ATM200_SCORE5_P100_350 | 5.000 | 5 | -4658.000 | 0.116 | -3425.000 | 21542.000 | -34.000 |
| 2026-04-29 | LOOSE_CTX_ATM100_SCORE4_P80_300 | 19.000 | 19 | -5781.000 | 0.676 | -7206.000 | 20419.000 | -20.000 |
| 2026-04-29 | ATM100_SCORE4_TRANSMISSION | 24.000 | 23 | 3253.000 | 1.154 | -8026.000 | 29453.000 | -16.000 |
| 2026-04-29 | ATM100_SCORE4_STRONG_TRANSMISSION | 22.000 | 21 | 61.000 | 1.003 | -8576.000 | 26261.000 | -18.000 |
| 2026-04-29 | ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | 0.000 | 0 | 0.000 |  | 0.000 | 26200.000 | -39.000 |
| 2026-04-29 | CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | 0.000 | 0 | 0.000 |  | 0.000 | 26200.000 | -39.000 |

## Filter Ablation
| base_variant | ablation_name | days | total_trades | total_net_pnl | average_day_pnl | worst_day_pnl | avg_profit_factor | avg_trade_count | max_drawdown_sum | delta_total_pnl_vs_base | delta_trade_count_vs_base | delta_worst_day_vs_base | delta_profit_factor_vs_base |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | baseline | 3 | 6 | 17424.000 | 5808.000 | 0.000 | 11.421 | 2.000 | -1672.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | remove_atm_filter | 3 | 144 | -10422.000 | -3474.000 | -11325.000 | 0.633 | 48.000 | -38780.000 | -27846.000 | 138.000 | -11325.000 | -10.788 |
| ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | remove_premium_band | 3 | 16 | 18616.000 | 6205.333 | -800.000 | 2.035 | 5.333 | -2682.000 | 1192.000 | 10.000 | -800.000 | -9.386 |
| ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | remove_abs_spread | 3 | 6 | 17424.000 | 5808.000 | 0.000 | 11.421 | 2.000 | -1672.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | remove_spread_pct | 3 | 6 | 17424.000 | 5808.000 | 0.000 | 11.421 | 2.000 | -1672.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | remove_depth_filter | 3 | 232 | -61144.000 | -20381.333 | -61144.000 | 0.693 | 77.333 | -60095.000 | -78568.000 | 226.000 | -61144.000 | -10.728 |
| ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | remove_top1_ranking | 3 | 6 | 17424.000 | 5808.000 | 0.000 | 11.421 | 2.000 | -1672.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | remove_cooldown | 3 | 6 | 17424.000 | 5808.000 | 0.000 | 11.421 | 2.000 | -1672.000 | 0.000 | 0.000 | 0.000 | 0.000 |
| CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | baseline | 3 | 0 | 0.000 | 0.000 | 0.000 |  | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |  |
| CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | remove_atm_filter | 3 | 10 | 155.000 | 51.667 | 0.000 | 1.016 | 3.333 | -9215.000 | 155.000 | 10.000 | 0.000 |  |
| CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | remove_premium_band | 3 | 0 | 0.000 | 0.000 | 0.000 |  | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |  |
| CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | remove_abs_spread | 3 | 0 | 0.000 | 0.000 | 0.000 |  | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |  |
| CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | remove_spread_pct | 3 | 0 | 0.000 | 0.000 | 0.000 |  | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |  |
| CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | remove_depth_filter | 3 | 22 | -6939.000 | -2313.000 | -6939.000 | 0.548 | 7.333 | -8565.000 | -6939.000 | 22.000 | -6939.000 |  |
| CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | remove_context | 3 | 0 | 0.000 | 0.000 | 0.000 |  | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |  |
| CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | remove_top1_ranking | 3 | 0 | 0.000 | 0.000 | 0.000 |  | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |  |
| CTX_ATM_ONLY_SCORE5_P100_300_SPREAD1P5_DEPTH500 | remove_cooldown | 3 | 0 | 0.000 | 0.000 | 0.000 |  | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |  |

## Best And Worst Replay Trades
| bucket | variant_name | date | timestamp | symbol | side | strike | atm_distance_points | atm_distance_abs | ltp | spread | spread_pct | depth_min_qty | score | score_components | entry_price | exit_price | points_pnl | gross_pnl | net_pnl | exit_reason | rank_score | candle_context | context_agrees | loose_context_agrees |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| top_winner | ATM100_SCORE4_TRANSMISSION | 2026-04-29 | 2026-04-29 13:38:50 | BFO:SENSEX26APR77800PE | PUT | 77800.000 | -100 | 100 | 281.850 | 0.100 | 0.000 | 380.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 1, "opt_velocity": 1} | 281.850 | 289.500 | 7.650 | 8109.000 | 8109.000 | TARGET_HIT | 5748.825 | bullish | False | False |
| top_winner | ATM100_SCORE4_STRONG_TRANSMISSION | 2026-04-29 | 2026-04-29 13:38:50 | BFO:SENSEX26APR77800PE | PUT | 77800.000 | -100 | 100 | 281.850 | 0.100 | 0.000 | 380.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 1, "opt_velocity": 1} | 281.850 | 289.500 | 7.650 | 8109.000 | 8109.000 | TARGET_HIT | 5748.825 | bullish | False | False |
| top_winner | ATM200_SCORE5_P100_350_SPREAD2_DEPTH250 | 2026-04-29 | 2026-04-29 13:38:50 | BFO:SENSEX26APR77800PE | PUT | 77800.000 | -100 | 100 | 281.850 | 0.100 | 0.000 | 380.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 1, "opt_velocity": 1} | 281.850 | 289.500 | 7.650 | 8109.000 | 8109.000 | TARGET_HIT | 5748.825 | bullish | False | False |
| top_winner | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 2026-04-29 | 2026-04-29 13:38:50 | BFO:SENSEX26APR77800PE | PUT | 77800.000 | -100 | 100 | 281.850 | 0.100 | 0.000 | 380.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 1, "opt_velocity": 1} | 281.850 | 289.500 | 7.650 | 8109.000 | 8109.000 | TARGET_HIT | 5748.825 | bullish | False | False |
| top_winner | ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | 2026-04-29 | 2026-04-29 13:38:50 | BFO:SENSEX26APR77800PE | PUT | 77800.000 | -100 | 100 | 281.850 | 0.100 | 0.000 | 380.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 1, "opt_velocity": 1} | 281.850 | 289.500 | 7.650 | 8109.000 | 8109.000 | TARGET_HIT | 5748.825 | bullish | False | False |
| top_winner | ATM100_SCORE4_STRONG_TRANSMISSION | 2026-04-29 | 2026-04-29 10:02:24 | BFO:SENSEX26APR77700CE | CALL | 77700.000 | 100 | 100 | 291.200 | 0.050 | 0.000 | 280.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 1, "opt_depth_imbalance": 0, "opt_velocity": 1} | 291.200 | 298.850 | 7.650 | 7803.000 | 7803.000 | TARGET_HIT | 6338.192 | neutral | False | True |
| top_winner | ATM100_SCORE4_TRANSMISSION | 2026-04-29 | 2026-04-29 10:02:24 | BFO:SENSEX26APR77700CE | CALL | 77700.000 | 100 | 100 | 291.200 | 0.050 | 0.000 | 280.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 1, "opt_depth_imbalance": 0, "opt_velocity": 1} | 291.200 | 298.850 | 7.650 | 7803.000 | 7803.000 | TARGET_HIT | 6338.192 | neutral | False | True |
| top_winner | ATM200_SCORE5_P100_350_SPREAD2_DEPTH250 | 2026-04-29 | 2026-04-29 10:02:24 | BFO:SENSEX26APR77700CE | CALL | 77700.000 | 100 | 100 | 291.200 | 0.050 | 0.000 | 280.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 1, "opt_depth_imbalance": 0, "opt_velocity": 1} | 291.200 | 298.850 | 7.650 | 7803.000 | 7803.000 | TARGET_HIT | 6338.192 | neutral | False | True |
| top_winner | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 2026-04-29 | 2026-04-29 10:02:24 | BFO:SENSEX26APR77700CE | CALL | 77700.000 | 100 | 100 | 291.200 | 0.050 | 0.000 | 280.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 1, "opt_depth_imbalance": 0, "opt_velocity": 1} | 291.200 | 298.850 | 7.650 | 7803.000 | 7803.000 | TARGET_HIT | 6338.192 | neutral | False | True |
| top_winner | LOOSE_CTX_ATM100_SCORE4_P80_300 | 2026-04-29 | 2026-04-29 10:02:24 | BFO:SENSEX26APR77700CE | CALL | 77700.000 | 100 | 100 | 291.200 | 0.050 | 0.000 | 280.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 1, "opt_depth_imbalance": 0, "opt_velocity": 1} | 291.200 | 298.850 | 7.650 | 7803.000 | 7803.000 | TARGET_HIT | 6338.192 | neutral | False | True |
| top_winner | ATM100_SCORE5_P80_300_SPREAD2_DEPTH250 | 2026-04-29 | 2026-04-29 10:02:24 | BFO:SENSEX26APR77700CE | CALL | 77700.000 | 100 | 100 | 291.200 | 0.050 | 0.000 | 280.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 1, "opt_depth_imbalance": 0, "opt_velocity": 1} | 291.200 | 298.850 | 7.650 | 7803.000 | 7803.000 | TARGET_HIT | 6338.192 | neutral | False | True |
| top_winner | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 2026-04-29 | 2026-04-29 09:40:08 | BFO:SENSEX26APR77200PE | PUT | 77200.000 | 0 | 0 | 280.150 | 0.050 | 0.000 | 320.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 1, "opt_velocity": 0} | 280.150 | 285.400 | 5.250 | 5565.000 | 5565.000 | TARGET_HIT | 4056.065 | bullish | False | False |
| top_winner | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 2026-04-29 | 2026-04-29 13:36:46 | BFO:SENSEX26APR78000CE | CALL | 78000.000 | 100 | 100 | 276.500 | 0.700 | 0.003 | 300.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 276.500 | 279.800 | 3.300 | 3564.000 | 3564.000 | TARGET_HIT | 4576.399 | bullish | True | True |
| top_winner | ATM100_SCORE4_TRANSMISSION | 2026-04-29 | 2026-04-29 13:36:46 | BFO:SENSEX26APR78000CE | CALL | 78000.000 | 100 | 100 | 276.500 | 0.700 | 0.003 | 300.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 276.500 | 279.800 | 3.300 | 3564.000 | 3564.000 | TARGET_HIT | 4576.399 | bullish | True | True |
| top_winner | CTX_ATM100_SCORE4_P80_300 | 2026-04-29 | 2026-04-29 13:36:46 | BFO:SENSEX26APR78000CE | CALL | 78000.000 | 100 | 100 | 276.500 | 0.700 | 0.003 | 300.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 276.500 | 279.800 | 3.300 | 3564.000 | 3564.000 | TARGET_HIT | 4576.399 | bullish | True | True |
| top_winner | ATM100_SCORE4_STRONG_TRANSMISSION | 2026-04-29 | 2026-04-29 13:36:46 | BFO:SENSEX26APR78000CE | CALL | 78000.000 | 100 | 100 | 276.500 | 0.700 | 0.003 | 300.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 276.500 | 279.800 | 3.300 | 3564.000 | 3564.000 | TARGET_HIT | 4576.399 | bullish | True | True |
| top_winner | LOOSE_CTX_ATM100_SCORE4_P80_300 | 2026-04-29 | 2026-04-29 13:36:46 | BFO:SENSEX26APR78000CE | CALL | 78000.000 | 100 | 100 | 276.500 | 0.700 | 0.003 | 300.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 276.500 | 279.800 | 3.300 | 3564.000 | 3564.000 | TARGET_HIT | 4576.399 | bullish | True | True |
| top_winner | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 2026-04-29 | 2026-04-29 09:36:16 | BFO:SENSEX26APR77300CE | CALL | 77300.000 | 100 | 100 | 298.850 | 0.550 | 0.002 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 1, "opt_depth_imbalance": 0, "opt_velocity": 0} | 298.850 | 302.400 | 3.550 | 3550.000 | 3550.000 | TARGET_HIT | 3427.776 | bearish | False | False |
| top_winner | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 2026-04-29 | 2026-04-29 14:40:18 | BFO:SENSEX26APR77700CE | CALL | 77700.000 | 100 | 100 | 284.650 | 0.750 | 0.003 | 340.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 1, "opt_velocity": 0} | 284.650 | 287.950 | 3.300 | 3432.000 | 3432.000 | TARGET_HIT | 4297.344 | bearish | False | False |
| top_winner | ATM100_SCORE4_TRANSMISSION | 2026-04-29 | 2026-04-29 14:40:18 | BFO:SENSEX26APR77700CE | CALL | 77700.000 | 100 | 100 | 284.650 | 0.750 | 0.003 | 340.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 1, "opt_velocity": 0} | 284.650 | 287.950 | 3.300 | 3432.000 | 3432.000 | TARGET_HIT | 4297.344 | bearish | False | False |
| top_loser | LOOSE_CTX_ATM100_SCORE4_P80_300 | 2026-04-29 | 2026-04-29 09:51:18 | BFO:SENSEX26APR77500CE | CALL | 77500.000 | 100 | 100 | 295.550 | 0.550 | 0.002 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 295.550 | 291.250 | -4.300 | -4300.000 | -4300.000 | EARLY_FAIL_3S | 4856.969 | bullish | True | True |
| top_loser | CTX_ATM100_SCORE4_P80_300 | 2026-04-29 | 2026-04-29 09:51:18 | BFO:SENSEX26APR77500CE | CALL | 77500.000 | 100 | 100 | 295.550 | 0.550 | 0.002 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 295.550 | 291.250 | -4.300 | -4300.000 | -4300.000 | EARLY_FAIL_3S | 4856.969 | bullish | True | True |
| top_loser | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 2026-04-29 | 2026-04-29 09:51:18 | BFO:SENSEX26APR77500CE | CALL | 77500.000 | 100 | 100 | 295.550 | 0.550 | 0.002 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 295.550 | 291.250 | -4.300 | -4300.000 | -4300.000 | EARLY_FAIL_3S | 4856.969 | bullish | True | True |
| top_loser | ATM100_SCORE4_TRANSMISSION | 2026-04-29 | 2026-04-29 09:51:18 | BFO:SENSEX26APR77500CE | CALL | 77500.000 | 100 | 100 | 295.550 | 0.550 | 0.002 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 295.550 | 291.250 | -4.300 | -4300.000 | -4300.000 | EARLY_FAIL_3S | 4856.969 | bullish | True | True |
| top_loser | ATM100_SCORE4_STRONG_TRANSMISSION | 2026-04-29 | 2026-04-29 09:51:18 | BFO:SENSEX26APR77500CE | CALL | 77500.000 | 100 | 100 | 295.550 | 0.550 | 0.002 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 295.550 | 291.250 | -4.300 | -4300.000 | -4300.000 | EARLY_FAIL_3S | 4856.969 | bullish | True | True |
| top_loser | ATM100_SCORE4_TRANSMISSION | 2026-04-29 | 2026-04-29 14:29:48 | BFO:SENSEX26APR77500PE | PUT | 77500.000 | 0 | 0 | 294.100 | 0.850 | 0.003 | 300.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 294.100 | 290.300 | -3.800 | -3876.000 | -3876.000 | EARLY_FAIL_3S | 4592.705 | bullish | False | False |
| top_loser | ATM100_SCORE4_STRONG_TRANSMISSION | 2026-04-29 | 2026-04-29 14:29:48 | BFO:SENSEX26APR77500PE | PUT | 77500.000 | 0 | 0 | 294.100 | 0.850 | 0.003 | 300.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 294.100 | 290.300 | -3.800 | -3876.000 | -3876.000 | EARLY_FAIL_3S | 4592.705 | bullish | False | False |
| top_loser | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 2026-04-29 | 2026-04-29 14:29:48 | BFO:SENSEX26APR77500PE | PUT | 77500.000 | 0 | 0 | 294.100 | 0.850 | 0.003 | 300.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 294.100 | 290.300 | -3.800 | -3876.000 | -3876.000 | EARLY_FAIL_3S | 4592.705 | bullish | False | False |
| top_loser | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 2026-04-29 | 2026-04-29 13:48:52 | BFO:SENSEX26APR77600PE | PUT | 77600.000 | -100 | 100 | 236.750 | 0.600 | 0.003 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 236.750 | 234.250 | -2.500 | -3150.000 | -3150.000 | EARLY_FAIL_3S | 4654.416 | neutral | False | True |
| top_loser | LOOSE_CTX_ATM100_SCORE4_P80_300 | 2026-04-29 | 2026-04-29 13:48:52 | BFO:SENSEX26APR77600PE | PUT | 77600.000 | -100 | 100 | 236.750 | 0.600 | 0.003 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 236.750 | 234.250 | -2.500 | -3150.000 | -3150.000 | EARLY_FAIL_3S | 4654.416 | neutral | False | True |
| top_loser | ATM100_SCORE4_TRANSMISSION | 2026-04-29 | 2026-04-29 13:48:52 | BFO:SENSEX26APR77600PE | PUT | 77600.000 | -100 | 100 | 236.750 | 0.600 | 0.003 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 236.750 | 234.250 | -2.500 | -3150.000 | -3150.000 | EARLY_FAIL_3S | 4654.416 | neutral | False | True |
| top_loser | ATM100_SCORE4_STRONG_TRANSMISSION | 2026-04-29 | 2026-04-29 13:48:52 | BFO:SENSEX26APR77600PE | PUT | 77600.000 | -100 | 100 | 236.750 | 0.600 | 0.003 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 236.750 | 234.250 | -2.500 | -3150.000 | -3150.000 | EARLY_FAIL_3S | 4654.416 | neutral | False | True |
| top_loser | CTX_ATM200_SCORE5_P100_350 | 2026-04-29 | 2026-04-29 14:31:25 | BFO:SENSEX26APR77300PE | PUT | 77300.000 | -200 | 200 | 204.850 | 0.400 | 0.002 | 740.000 | 6 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 1, "opt_depth_imbalance": 1, "opt_velocity": 1} | 204.850 | 202.800 | -2.050 | -2993.000 | -2993.000 | EARLY_FAIL_1S | 6545.728 | bearish | True | True |
| top_loser | ATM200_SCORE5_P100_350_SPREAD2_DEPTH250 | 2026-04-29 | 2026-04-29 14:31:25 | BFO:SENSEX26APR77300PE | PUT | 77300.000 | -200 | 200 | 204.850 | 0.400 | 0.002 | 740.000 | 6 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 1, "opt_depth_imbalance": 1, "opt_velocity": 1} | 204.850 | 202.800 | -2.050 | -2993.000 | -2993.000 | EARLY_FAIL_1S | 6545.728 | bearish | True | True |
| top_loser | LOOSE_CTX_ATM100_SCORE4_P80_300 | 2026-04-29 | 2026-04-29 10:00:48 | BFO:SENSEX26APR77600CE | CALL | 77600.000 | 100 | 100 | 294.000 | 0.900 | 0.003 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 294.000 | 292.100 | -1.900 | -1938.000 | -1938.000 | EARLY_FAIL_1S | 5540.810 | neutral | False | True |
| top_loser | ATM100_SCORE4_P80_300_SPREAD1P5_DEPTH250 | 2026-04-29 | 2026-04-29 10:00:48 | BFO:SENSEX26APR77600CE | CALL | 77600.000 | 100 | 100 | 294.000 | 0.900 | 0.003 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 294.000 | 292.100 | -1.900 | -1938.000 | -1938.000 | EARLY_FAIL_1S | 5540.810 | neutral | False | True |
| top_loser | ATM100_SCORE4_STRONG_TRANSMISSION | 2026-04-29 | 2026-04-29 10:00:48 | BFO:SENSEX26APR77600CE | CALL | 77600.000 | 100 | 100 | 294.000 | 0.900 | 0.003 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 294.000 | 292.100 | -1.900 | -1938.000 | -1938.000 | EARLY_FAIL_1S | 5540.810 | neutral | False | True |
| top_loser | ATM100_SCORE4_TRANSMISSION | 2026-04-29 | 2026-04-29 10:00:48 | BFO:SENSEX26APR77600CE | CALL | 77600.000 | 100 | 100 | 294.000 | 0.900 | 0.003 | 260.000 | 4 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 0, "opt_velocity": 1} | 294.000 | 292.100 | -1.900 | -1938.000 | -1938.000 | EARLY_FAIL_1S | 5540.810 | neutral | False | True |
| top_loser | ATM200_SCORE5_P100_350_SPREAD2_DEPTH250 | 2026-04-29 | 2026-04-29 11:50:00 | BFO:SENSEX26APR78000CE | CALL | 78000.000 | 200 | 200 | 249.800 | 0.450 | 0.002 | 320.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 0, "opt_depth_imbalance": 1, "opt_velocity": 1} | 249.800 | 248.350 | -1.450 | -1740.000 | -1740.000 | EARLY_FAIL_1S | 6182.790 | bearish | False | False |
| top_loser | ATM200_SCORE5_P100_350_SPREAD2_DEPTH250 | 2026-04-29 | 2026-04-29 11:09:48 | BFO:SENSEX26APR77700PE | PUT | 77700.000 | -200 | 200 | 250.550 | 0.550 | 0.002 | 300.000 | 5 | {"ind_accel_threshold_1": 2, "ind_accel_threshold_2": 1, "ind_velocity_band": 1, "opt_depth_imbalance": 1, "opt_velocity": 0} | 250.550 | 249.100 | -1.450 | -1711.000 | -1711.000 | PROMOTED_FAIL_3S | 4905.490 | bearish | True | True |

## Final Verdict
- **Did near-ATM filtering reduce overtrading?** Yes, relative to the earlier broad burst study, but not enough. Trade counts are lower than the broad-tape burst variants, yet still far above the live system in most variants.
- **Did any variant beat the actual live system?** Arithmetic answer: Yes. Robust answer after requiring at least 5 trades across at least 2 active days: **No**.
- **Did any variant produce positive total PnL?** Yes.
- **Best overall research variant:** `ATM100_SCORE5_P80_300_SPREAD2_DEPTH250` with total net `17,424`, worst day `0`, total trades `6`, and active days `1`. This is still not live-patch ready.
- **Is edge concentrated in ATM / ATM±100?** Yes, the only profitable variants are the strict ATM/ATM±100 and ATM/ATM±200 score-heavy variants. But the profitable behavior is concentrated almost entirely in one tape day, so the edge is not yet robust.
- **Which premium band worked best?** The better-performing strict variants concentrated in the 80-300 / 100-300 premium ranges, which is directionally consistent with the liquidity thesis, but still insufficient for a deployable edge.
- **Which filter mattered most?** ATM distance and depth matter most in this sample. Removing the ATM filter turned the best strict variant from `+17,424` to `-10,422`. Removing the depth filter collapsed it to `-61,144` with 232 trades.
- **Is candle context useful after contract filtering?** Not in this sample. The best context-aware traded variant was `CTX_ATM200_SCORE5_P100_350`, and it remained negative.
- **Is one-position-at-a-time enough?** No. It helps, but the stronger result here is that selective contract filtering matters more than the one-position rule alone.
- **Are we closer to a tradable edge?** Slightly closer diagnostically, not operationally. We have narrowed the hypothesis, but no tested variant is ready for a live patch.
- **Live patch ready?** No.
- **Best research candidate next:** `ATM100_SCORE5_P80_300_SPREAD2_DEPTH250` as the strict near-ATM baseline for the next research round. If you keep testing candle context, treat it as a secondary branch, not the main branch.
- **What would falsify the strategy family?** If another round with stricter ranking, stronger cooldown, and perhaps ATM-only contract concentration still cannot beat the actual system on more full-tape days, then the near-ATM burst-onset thesis is likely not robust enough to justify this strategy family.

## Caveats
- This is still diagnostic replay, not broker-grade execution simulation.
- Tape coverage is limited. 2026-04-24 is partial and should carry less evidentiary weight.
- Replay uses current deterministic exits, so entry-edge conclusions are conditional on those exits.
- Raw logs were not modified.

## Charts
- ![variant_total_pnl.png](/Users/ankurkumar/Downloads/sensex-noise-papertrade/near_atm_burst_research_results/charts/variant_total_pnl.png)
- ![trade_count_vs_pnl.png](/Users/ankurkumar/Downloads/sensex-noise-papertrade/near_atm_burst_research_results/charts/trade_count_vs_pnl.png)
- ![variant_daywise_pnl.png](/Users/ankurkumar/Downloads/sensex-noise-papertrade/near_atm_burst_research_results/charts/variant_daywise_pnl.png)
- ![premium_band_performance.png](/Users/ankurkumar/Downloads/sensex-noise-papertrade/near_atm_burst_research_results/charts/premium_band_performance.png)
- ![atm_distance_performance.png](/Users/ankurkumar/Downloads/sensex-noise-papertrade/near_atm_burst_research_results/charts/atm_distance_performance.png)